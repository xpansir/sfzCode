﻿// Printer.cpp : 定义应用程序的入口点。
//

#include "stdafx.h"
#include "Printer.h"
#include <atlstr.h>
#include "windows.h"

#include "winspool.h"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名

// 此代码模块中包含的函数的前向声明:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
// zhangyu 代码前向声明

BOOL SaveBmp(HBITMAP hBitmap, CString FileName);
HBITMAP CopyDCToBitmap(HDC hScrDC, LPRECT lpRect);
HDC GetPrinterHDC(void);
void CallPrinter();
void PrintTemporaryIdentityCard();


////////////
HANDLE LoadBMP(LPCTSTR lpFileName);
bool PaintBMP(HDC hDC, LPRECT lpDCRect, HANDLE hBMP, LPRECT lpBMPRect, HPALETTE hPalette);
/////////////////////////////////////////////////////////////////////////////////////////////
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_PRINTER, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 执行应用程序初始化:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_PRINTER));

    MSG msg;

    // 主消息循环:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  函数: MyRegisterClass()
//
//  目标: 注册窗口类。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PRINTER));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_PRINTER);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 将实例句柄存储在全局变量中

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  函数: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目标: 处理主窗口的消息。
//
//  WM_COMMAND  - 处理应用程序菜单
//  WM_PAINT    - 绘制主窗口
//  WM_DESTROY  - 发送退出消息并返回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	/*
	 * 静态文本框
	 */
	static HWND hwd_static_name;
	static HWND hwd_static_sex;
	static HWND hwd_static_nation;
	static HWND hwd_static_birthPlace;
	static HWND hwd_static_address;
	static HWND hwd_static_validityPeriod;
	static HWND hwd_static_organization;
	static HWND hwd_static_id;
	//////////////////////////////////////////////////////////////////////////////////////
	/*
	 * 输入文本框
     */
	static HWND hwd_edit_name;
	static HWND hwd_edit_sex;
	static HWND hwd_edit_nation;
	static HWND hwd_edit_birthPlace;
	static HWND hwd_edit_address;
	static HWND hwd_edit_validityPeriod;
	static HWND hwd_edit_organization;
	static HWND hwd_edit_id;

	//////////////////////////////////////////////////////////////////////////////////////
	static HWND hwd_button_ok;


/*	static int CONTROL_TOP = 20;
	static int STATIC_LEFT = 20;
	static int STATIC_WIDTH = 60;
	static int STATIC_HEIGHT = 20;
	
	static int EDIT_LEFT = 60;
	static int EDIT_WIDTH = 60;
	static int EDIT_HEIGHT = 20;
	static int CONTROL_HEIGHT = 20;
	static int CONTROL_GAP = 10;*/
    switch (message)
    {
	case WM_CREATE:
		// 在此创建静态文本框控件
		hwd_static_name           = CreateWindow(TEXT("static"), TEXT("姓名"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 0, 90, 20, hWnd,
			(HMENU)1, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_sex            = CreateWindow(TEXT("static"), TEXT("性别"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 80, 30, 30, 20, hWnd,
			(HMENU)2, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_nation         = CreateWindow(TEXT("static"), TEXT("民族"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 190, 30, 30, 20, hWnd,
			(HMENU)3, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_birthPlace     = CreateWindow(TEXT("static"), TEXT("出生"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 60, 90, 20, hWnd,
			(HMENU)4, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_address        = CreateWindow(TEXT("static"), TEXT("住址"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 90, 90, 20, hWnd,
			(HMENU)5, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_validityPeriod = CreateWindow(TEXT("static"), TEXT("有效期限"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 120, 90, 20, hWnd,
			(HMENU)6, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_organization   = CreateWindow(TEXT("static"), TEXT("签发机关"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 150, 90, 20, hWnd,
			(HMENU)7, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		hwd_static_id             = CreateWindow(TEXT("static"), TEXT("公民身份证号"), WS_CHILD | WS_VISIBLE | SS_RIGHT, 20, 180, 90, 20, hWnd,
			(HMENU)8, ((LPCREATESTRUCT)lParam)->hInstance, NULL);
		// 在此创建编辑文本框控件
		hwd_edit_name           = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 0, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_sex            = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 30, 50, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_nation         = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			230, 30, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_birthPlace     = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 60, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_address        = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 90, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_validityPeriod = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 120, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_organization   = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 150, 200, 20, hWnd, NULL, NULL, NULL);
		hwd_edit_id             = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
			130, 180, 200, 20, hWnd, NULL, NULL, NULL);
	
		hwd_button_ok = CreateWindow(TEXT("button"),TEXT("确定"),WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,350,180,60,24,hWnd,(HMENU)1,((LPCREATESTRUCT)lParam)->hInstance,NULL);
		break;
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 分析菜单选择:
            switch (wmId)
            {
            case IDM_ABOUT:

               // DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
				PrintTemporaryIdentityCard();
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: 在此处添加使用 hdc 的任何绘图代码...
		/*	int width       = ps.rcPaint.right - ps.rcPaint.left;
			int height      = ps.rcPaint.bottom - ps.rcPaint.top;
			HDC memHdc      = CreateCompatibleDC(hdc);
			HBITMAP hBitmap = CreateCompatibleBitmap(hdc, width, height);
			SelectObject(memHdc, hBitmap);
			//PatBlt(memHdc, 0, 0, width, height, WHITENESS);
			TextOut(memHdc, 100, 100, L"姓名 张雨",wcslen(L"姓名 张雨"));
			TextOut(memHdc, 100, 120, L"性别 男 民族 汉",wcslen(L"性别 男 民族 汉"));
			TextOut(memHdc, 100, 140, L"出生 1990 年 11 月 09 日", wcslen(L"出生 1990 年 11 月 09 日"));
			TextOut(memHdc, 100, 160, L"住址 江苏省淮安市淮阴区王营镇黄河小区119号", wcslen(L"住址 江苏省淮安市淮阴区王营镇黄河小区119号"));

			TextOut(memHdc, 100, 200, L"有效期限 2018.02.14-2018.05.14", wcslen(L"有效期限 2018.02.14-2018.05.14"));
			TextOut(memHdc, 100, 220, L"签发机关 清江浦区公安局", wcslen(L"签发机关 清江浦区公安局"));
			TextOut(memHdc, 100, 240, L"公民身份证号 320804199009020150", wcslen(L"公民身份证号 320804199009020150"));
         
			BitBlt(hdc, 0, 0, width, height, memHdc, 0, 0, SRCCOPY);
			
			DeleteObject(memHdc);
			DeleteObject(hBitmap);*/
			EndPaint(hWnd, &ps);
        }
        break;
	
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
// 以下是绘图代码
//将内存绘制的图保存为 HBITMAP，调用时可以按照尺寸只截取整个绘图区域的一部分
HBITMAP CopyDCToBitmap(HDC hScrDC, LPRECT lpRect)
{
	HDC hMemDC;
	// 屏幕和内存设备描述表
	HBITMAP hBitmap, hOldBitmap;
	// 位图句柄
	int nX, nY, nX2, nY2;
	// 选定区域坐标
	int nWidth, nHeight;
	// 位图宽度和高度

	// 确保选定区域不为空矩形
	if (IsRectEmpty(lpRect)) return NULL;

	// 获得选定区域坐标
	nX      = lpRect->left;
	nY      = lpRect->top;
	nX2     = lpRect->right;
	nY2     = lpRect->bottom;
	nWidth  = nX2 - nX;
	nHeight = nY2 - nY;
	//为屏幕设备描述表创建兼容的内存设备描述表
	hMemDC     = CreateCompatibleDC(hScrDC);
	// 创建一个与屏幕设备描述表兼容的位图
	hBitmap    = CreateCompatibleBitmap(hScrDC, nWidth, nHeight);
	// 把新位图选到内存设备描述表中
	hOldBitmap = (HBITMAP)SelectObject(hMemDC, hBitmap);
	// 把屏幕设备描述表拷贝到内存设备描述表中
	StretchBlt(hMemDC, 0, 0, nWidth, nHeight, hScrDC, nX, nY, nWidth, nHeight, SRCCOPY);
	//得到屏幕位图的句柄
	hBitmap    = (HBITMAP)SelectObject(hMemDC, hOldBitmap);
	//清除
	DeleteDC(hMemDC);
	DeleteObject(hOldBitmap);
	//返回位图句柄
	return hBitmap;
}


///////////////////

//保存到BMP文件
BOOL SaveBmp(HBITMAP hBitmap, CString FileName)
{
	HDC hDC;
	//当前分辨率下每象素所占字节数
	int iBits;
	//位图中每象素所占字节数
	WORD wBitCount;
	//定义调色板大小， 位图中像素字节大小 ，位图文件大小 ， 写入文件字节数
	DWORD dwPaletteSize = 0, dwBmBitsSize = 0, dwDIBSize = 0, dwWritten = 0;
	//位图属性结构
	BITMAP Bitmap;
	//位图文件头结构
	BITMAPFILEHEADER bmfHdr;
	//位图信息头结构
	BITMAPINFOHEADER bi;
	//指向位图信息头结构
	LPBITMAPINFOHEADER lpbi;
	//定义文件，分配内存句柄，调色板句柄
	HANDLE fh, hDib, hPal, hOldPal = NULL;

	//计算位图文件每个像素所占字节数
	hDC = CreateDC(L"DISPLAY", NULL, NULL, NULL);
	iBits = GetDeviceCaps(hDC, BITSPIXEL) * GetDeviceCaps(hDC, PLANES);
	DeleteDC(hDC);
	if (iBits <= 1) wBitCount = 1;
	else if (iBits <= 4) wBitCount = 4;
	else if (iBits <= 8) wBitCount = 8;
	else wBitCount = 24;

	GetObject(hBitmap, sizeof(Bitmap), (LPSTR)&Bitmap);
	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = Bitmap.bmWidth;
	bi.biHeight = Bitmap.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = wBitCount;
	bi.biCompression = BI_RGB;
	bi.biSizeImage   = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrImportant = 0;
	bi.biClrUsed = 0;

	dwBmBitsSize = ((Bitmap.bmWidth * wBitCount + 31) / 32) * 4 * Bitmap.bmHeight;

	//为位图内容分配内存
	hDib = GlobalAlloc(GHND, dwBmBitsSize + dwPaletteSize + sizeof(BITMAPINFOHEADER));
	lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDib);
	*lpbi = bi;

	// 处理调色板
	hPal = GetStockObject(DEFAULT_PALETTE);
	if (hPal)
	{
		hDC = ::GetDC(NULL);
		//hDC = m_pDc->GetSafeHdc();
		hOldPal = ::SelectPalette(hDC, (HPALETTE)hPal, FALSE);
		RealizePalette(hDC);
	}
	// 获取该调色板下新的像素值
	GetDIBits(hDC, hBitmap, 0, (UINT)Bitmap.bmHeight, (LPSTR)lpbi + sizeof(BITMAPINFOHEADER)
		+ dwPaletteSize, (BITMAPINFO *)lpbi, DIB_RGB_COLORS);

	//恢复调色板
	if (hOldPal)
	{
		::SelectPalette(hDC, (HPALETTE)hOldPal, TRUE);
		RealizePalette(hDC);
		::ReleaseDC(NULL, hDC);
	}


	//创建位图文件
	fh = CreateFile(FileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	if (fh == INVALID_HANDLE_VALUE) return FALSE;

	// 设置位图文件头
	bmfHdr.bfType = 0x4D42; // "BM"
	dwDIBSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + dwPaletteSize + dwBmBitsSize;
	bmfHdr.bfSize = dwDIBSize;
	bmfHdr.bfReserved1 = 0;
	bmfHdr.bfReserved2 = 0;
	bmfHdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER) + dwPaletteSize;
	// 写入位图文件头
	WriteFile(fh, (LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER), &dwWritten, NULL);
	// 写入位图文件其余内容
	WriteFile(fh, (LPSTR)lpbi, dwDIBSize, &dwWritten, NULL);
	//清除
	GlobalUnlock(hDib);
	GlobalFree(hDib);
	CloseHandle(fh);

	return TRUE;
}
//// 打印临时身份证
void PrintTemporaryIdentityCard()
{
	
	static DOCINFO di = { sizeof(DOCINFO),TEXT("hello world") };
	HDC printerDc = GetPrinterHDC();

	StartDoc(printerDc, &di);
	StartPage(printerDc);
	/// 

	int width  = GetDeviceCaps(printerDc,HORZRES);  //4800
	int height = GetDeviceCaps(printerDc, VERTRES); //6826
	HDC memHdc = CreateCompatibleDC(printerDc);
	HBITMAP hBitmap = CreateCompatibleBitmap(printerDc, width, height);
	SelectObject(memHdc, hBitmap);
	PatBlt(memHdc,0, 0, width, height, WHITENESS);
	//// 画边框
	RECT cardRect = { 1970,1,4050,1345 };
	MoveToEx(memHdc, cardRect.left, cardRect.top, NULL);
	LineTo(memHdc, cardRect.left, cardRect.bottom);
	//LineTo(memHdc, cardRect.right, cardRect.bottom);
	//LineTo(memHdc, cardRect.left, cardRect.bottom);
	MoveToEx(memHdc, cardRect.right, cardRect.top,NULL);
	LineTo(memHdc, cardRect.right, cardRect.bottom);
	////

	RECT contextRect = { 2065,96,3955,1250 };//内容矩形
	//569 1154
	RECT captureRect = {3386 ,296,3955,940 }; // 头像矩形
	HFONT font = CreateFont(66,                                    //   字体的高度   
		0,                                          //   字体的宽度  
		0,                                          //  nEscapement 
		0,                                          //  nOrientation   
		FW_NORMAL,                                  //   nWeight   
		FALSE,                                      //   bItalic   
		FALSE,                                      //   bUnderline   
		0,                                                   //   cStrikeOut   
		ANSI_CHARSET,                             //   nCharSet   
		OUT_DEFAULT_PRECIS,                 //   nOutPrecision   
		CLIP_DEFAULT_PRECIS,               //   nClipPrecision   
		DEFAULT_QUALITY,                       //   nQuality   
		DEFAULT_PITCH | FF_SWISS,     //   nPitchAndFamily     
		_T("黑体"));
	HFONT oldFont = (HFONT)SelectObject(memHdc, font);
	TextOut(memHdc, contextRect.left, contextRect.top, L"姓名 张雨", wcslen(L"姓名 张雨"));
	TextOut(memHdc, contextRect.left, contextRect.top + 150, L"性别 男 民族 汉", wcslen(L"性别 男 民族 汉"));
	TextOut(memHdc, contextRect.left, contextRect.top + 300, L"出生 1990 年 11 月 09 日", wcslen(L"出生 1990 年 11 月 09 日"));
	TextOut(memHdc, contextRect.left, contextRect.top + 450, L"住址 江苏省淮安市淮阴区", wcslen(L"住址 江苏省淮安市淮阴区"));
    //王营镇黄河小区119号
	//王营镇黄河小区119号
	TextOut(memHdc, contextRect.left, contextRect.top + 750, L"有效期限 2018.02.14-2018.05.14", wcslen(L"有效期限 2018.02.14-2018.05.14"));
	TextOut(memHdc, contextRect.left, contextRect.top + 900, L"签发机关 清江浦区公安局", wcslen(L"签发机关 清江浦区公安局"));
	TextOut(memHdc, contextRect.left, contextRect.top + 1050, L"公民身份证号 320804199009020150", wcslen(L"公民身份证号 320804199009020150"));
	/////
	SelectObject(memHdc, oldFont);
	HANDLE hBmp = LoadBMP((CString)"E:\\abm.bmp");
	

	LPBITMAPINFOHEADER lpBMP = (LPBITMAPINFOHEADER)GlobalLock(hBmp);
	RECT bmp_Rect = { 0,0,lpBMP->biWidth,lpBMP->biHeight };

	PaintBMP(memHdc, &captureRect, hBmp, &bmp_Rect, NULL);

	/////
	/*int context_x = 10;
	int context_y = 100;
	int context_w = 4000;
	int context_h = 2000;*/
	for (int x = contextRect.left; x < contextRect.left + (contextRect.right-contextRect.left)/2; x++)
	{
		for (int y = contextRect.top; y < contextRect.bottom; y++)
		{
			COLORREF l_c = GetPixel(memHdc, x, y);
			COLORREF r_c = GetPixel(memHdc, contextRect.right - (x - contextRect.left), y);
			if (l_c != r_c)
			{
				SetPixel(memHdc, x, y, r_c);
				SetPixel(memHdc, contextRect.right - (x - contextRect.left), y, l_c);
			}
		}
	}

	BitBlt(printerDc, 0, 0, width, height, memHdc, 0, 0, SRCCOPY);


	DeleteObject(memHdc);
	DeleteObject(hBitmap);

	////////////////
	EndPage(printerDc);
	EndDoc(printerDc);
	DeleteDC(printerDc);

	
}
/////调用打印机
void CallPrinter()
{
	static DOCINFO di = { sizeof(DOCINFO),TEXT("hello world") };
	HDC printerDc     = GetPrinterHDC();
	
	StartDoc(printerDc, &di);
	StartPage(printerDc);
	TextOut(printerDc, 100, 50, L"临时身份证打印机", 8);
	EndPage(printerDc);
	EndDoc(printerDc);
	DeleteDC(printerDc);
}
//// 获取打印机设备上下文
HDC GetPrinterHDC(void)
{
	DWORD dwNeeded = 0, dwReturned =0;
	HDC printerHdc;
	PRINTER_INFO_4 * pinfo4;
	
	EnumPrinters(PRINTER_ENUM_LOCAL, NULL, 4, NULL, 0, &dwNeeded, &dwReturned);
	pinfo4 = (PRINTER_INFO_4*)malloc(dwNeeded);
	EnumPrinters(PRINTER_ENUM_LOCAL, NULL, 4,  (PBYTE)pinfo4, dwNeeded, &dwNeeded, &dwReturned);

	printerHdc = CreateDC(NULL, pinfo4->pPrinterName, NULL,NULL);
	free(pinfo4);
	return printerHdc;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 *以下是和位图相关的代码  
 */

// 载入位图
HANDLE LoadBMP(LPCTSTR lpFileName)
{
	HANDLE hBMP;  //载入数据所在缓冲区的句柄
	HANDLE hFile;
	BITMAPFILEHEADER bmfHeader;  //文件头
	UINT nNumColors;   //位图颜色表的颜色数
	HANDLE hBMPtmp;
	LPBITMAPINFOHEADER lpbmInfo;   //指向信息头的指针
	DWORD dwOffBits;  //像素阵列偏移量
	DWORD dwRead;

	if ((hFile = CreateFile((LPCWSTR)lpFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL)) == INVALID_HANDLE_VALUE)
	{
		return NULL;  //若打开文件失败，则返回NULL
	}
	//为位图信息头和颜色表分配初始内存，后续可根据实际需要扩大内存
	hBMP = GlobalAlloc(GMEM_MOVEABLE, (DWORD)(sizeof(BITMAPINFOHEADER) + 256 * sizeof(RGBQUAD)));
	if (!hBMP)
	{
		CloseHandle(hFile);
		return NULL;
	}
	lpbmInfo = (LPBITMAPINFOHEADER)GlobalLock(hBMP);  //指向信息头的指针
	if (!lpbmInfo)
	{
		goto ErrorExit_NoUnlock;
	}
	//从文件读入位图文件头BITMAPFILEHEADER
	if (!ReadFile(hFile, (LPBYTE)&bmfHeader, sizeof(BITMAPFILEHEADER), &dwRead, NULL))
	{
		goto ErrorExit;
	}
	if (sizeof(BITMAPFILEHEADER) != dwRead)
	{
		goto ErrorExit;
	}
	//读入位图信息头BITMAPINFOHEADER
	if (!ReadFile(hFile, (LPBYTE)lpbmInfo, sizeof(BITMAPINFOHEADER), &dwRead, NULL))
	{
		goto ErrorExit;
	}
	if (sizeof(BITMAPINFOHEADER) != dwRead)
	{
		goto ErrorExit;
	}
	//确定颜色大小
	if (!(nNumColors = (UINT)lpbmInfo->biClrUsed))
	{
		if (lpbmInfo->biBitCount != 24)  //如果非真彩色，则根据biBitCount计算颜色项数
		{
			nNumColors = 1 << lpbmInfo->biBitCount;
		}
	}
	if (lpbmInfo->biClrUsed == 0)
	{
		lpbmInfo->biClrUsed = nNumColors;
	}
	//计算像素阵列占用空间，字节对齐
	if (lpbmInfo->biSizeImage == 0)
	{
		lpbmInfo->biSizeImage = ((((lpbmInfo->biWidth*(DWORD)lpbmInfo->biBitCount) + 31)&~31) >> 3)*lpbmInfo->biHeight;
	}
	//重新根据图像实际大小分配内存，用于存放信息头、颜色表和像素阵列
	GlobalUnlock(hBMP);
	hBMPtmp = GlobalReAlloc(hBMP, lpbmInfo->biSize + nNumColors * sizeof(RGBQUAD) + lpbmInfo->biSizeImage, 0);
	if (!hBMPtmp)
	{
		goto ErrorExit_NoUnlock;
	}
	else
	{
		hBMP = hBMPtmp;
	}
	lpbmInfo = (LPBITMAPINFOHEADER)GlobalLock(hBMP);
	//读入颜色表
	ReadFile(hFile, (LPBYTE)(lpbmInfo)+lpbmInfo->biSize, nNumColors * sizeof(RGBQUAD), &dwRead, NULL);
	//计算像素阵列偏移量
	dwOffBits = lpbmInfo->biSize + nNumColors * sizeof(RGBQUAD);
	if (bmfHeader.bfOffBits != 0L)
	{
		SetFilePointer(hFile, bmfHeader.bfOffBits, NULL, FILE_BEGIN);
	}
	//读入图像像素阵列数据
	if (ReadFile(hFile, (LPBYTE)lpbmInfo + dwOffBits, lpbmInfo->biSizeImage, &dwRead, NULL))
	{
		goto SuccessExit;
	}
ErrorExit:
	GlobalUnlock(hBMP);
ErrorExit_NoUnlock:
	GlobalFree(hBMP);
	CloseHandle(hFile);
	return NULL;
SuccessExit:
	CloseHandle(hFile);
	GlobalUnlock(hBMP);
	return hBMP;
}
/////
WORD BMPColorNum(LPBYTE lpbmInfo)
{
	WORD wBitCount;
	//根据信息头的biBitCount计算颜色表项数
	wBitCount = ((LPBITMAPINFOHEADER)lpbmInfo)->biBitCount;
	switch (wBitCount)
	{
	case 1:
		return 2;
	case 4:
		return 16;
	case 8:
		return 256;
	default:
		return 0;
	}
}
//// 创建位图调色板
HPALETTE CreateBMPPalette(LPBYTE lpBMP)
{
	LPLOGPALETTE lpPalette;  //指向逻辑调色板的指针
	HANDLE hLogPal;   //逻辑调色板句柄
	HPALETTE hPalette = NULL;   //初始化调色板
	LPBITMAPINFO lpbmInfo;  //指向LPBITMAPINFO结构的指针
	int wNumColors;  //颜色表的颜色数
	int i;
	if (!lpBMP)  //若不是有效指针，则返回NULL,表示创建失败
		return NULL;
	lpbmInfo = (LPBITMAPINFO)lpBMP;  //指向位图信息块的指针
	wNumColors = BMPColorNum((LPBYTE)lpBMP);  //获取位图颜色表中的颜色数
	if (wNumColors)
	{
		//为逻辑调色板分配内存空间
		hLogPal = GlobalAlloc(GHND, sizeof(LOGPALETTE) + sizeof(PALETTEENTRY)*wNumColors);
		//若分配失败，则返回NULL
		if (!hLogPal)
			return NULL;
		lpPalette = (LPLOGPALETTE)GlobalLock(hLogPal);  //使lpPalette指向逻辑调色板
		//设置逻辑调色板
		lpPalette->palVersion = 0x300;  //逻辑调色板版本号
		lpPalette->palNumEntries = wNumColors;  //设置调色板颜色数
		//根据位图颜色表设置调色板颜色项
		for (i = 0; i < wNumColors; i++)
		{
			lpPalette->palPalEntry[i].peRed   = lpbmInfo->bmiColors[i].rgbRed;
			lpPalette->palPalEntry[i].peGreen = lpbmInfo->bmiColors[i].rgbGreen;
			lpPalette->palPalEntry[i].peBlue  = lpbmInfo->bmiColors[i].rgbBlue;
			lpPalette->palPalEntry[i].peFlags = 0;
		}
		hPalette = CreatePalette(lpPalette);  //创建调色板
		GlobalUnlock(hLogPal);
		GlobalFree(hLogPal);
		if (!hPalette) //如果创建失败，则返回NULL
			return NULL;
	}
	return hPalette;  //若创建成功则返回调色板句柄
}

//绘图
bool PaintBMP(HDC hDC, LPRECT lpDCRect, HANDLE hBMP, LPRECT lpBMPRect, HPALETTE hPalette)
{
	LPBYTE lpBMPHdr;   //指向位图数据的指针，即指向位图信息头
	LPBYTE lpBMPBits;  //指向位图要素阵列的指针
	BOOL bSuccessful = FALSE;  //函数StretchDIBits()是否成功执行
	HPALETTE hOldPal = NULL;  //原调色板句柄
	//若位图句柄hBMP=0则不能显示，返回FALSE
	if (!hBMP)
		return FALSE;
	//使lpBMPHdr指向位图信息头
	lpBMPHdr = (LPBYTE)GlobalLock(hBMP);
	//使lpBMPBits指向位图像素阵列
	lpBMPBits = lpBMPHdr + sizeof(BITMAPINFOHEADER) + BMPColorNum(lpBMPHdr) * sizeof(RGBQUAD);
	//若没有指定调色板，则调用函数CreateBMPalette()根据要显示位图的颜色表创建调色板
	if (!hPalette)
	{
		hPalette = CreateBMPPalette(lpBMPHdr);
	}
	//选择并实现指定的或新建的调色板，同时记录原调色板hOldPal
	if (hPalette)
	{
		hOldPal = SelectPalette(hDC, hPalette, TRUE);
		RealizePalette(hDC);
	}
	//设置位图拉伸模式
	SetStretchBltMode(hDC, COLORONCOLOR);
	//使用函数StretchDIBits()将位图图像矩形区域中像素使用的颜色数据复制到指定目标矩形中
	bSuccessful = StretchDIBits(hDC, lpDCRect->left, lpDCRect->top, lpDCRect->right - lpDCRect->left, lpDCRect->bottom - lpDCRect->top,
		lpBMPRect->left, ((LPBITMAPINFOHEADER)lpBMPHdr)->biHeight - lpBMPRect->top - (lpBMPRect->bottom - lpBMPRect->top),
		lpBMPRect->right - lpBMPRect->left, lpBMPRect->bottom - lpBMPRect->top,
		lpBMPBits, (LPBITMAPINFO)lpBMPHdr, DIB_RGB_COLORS, SRCCOPY);
	//重新选择原调色板
	if (hOldPal)
	{
		SelectPalette(hDC, hOldPal, FALSE);
	}
	GlobalUnlock(hBMP);
	return bSuccessful;
}

////////////////////////////////////////////////////////////////////////////////////////////////////